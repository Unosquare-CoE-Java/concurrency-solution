package coe.unosquare.model.dto;

import coe.unosquare.model.Order;

public record OrderDto(Order.OrderType orderType, Double price, Integer quantity) {
}
