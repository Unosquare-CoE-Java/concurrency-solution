package coe.unosquare.model;

import coe.unosquare.model.dto.OrderDto;

public class EntityDtoMapper {
    public static Order toEntity(OrderDto orderDto) {
        return new Order(orderDto.orderType(), orderDto.price(), orderDto.quantity());
    }

    public static OrderDto toDto(Order order) {
        return new OrderDto(order.getOrderType(), order.getPrice(), order.getQuantity());
    }
}
