package coe.unosquare.service;

import coe.unosquare.model.EntityDtoMapper;
import coe.unosquare.model.Order;
import coe.unosquare.model.OrderMatcher;
import coe.unosquare.model.dto.OrderDto;
import reactor.core.publisher.Mono;
import reactor.core.scheduler.Schedulers;
import org.springframework.stereotype.Service;

@Service
public class OrderService {
    private final OrderMatcher orderMatcher;

    public OrderService(OrderMatcher orderMatcher) {
        this.orderMatcher = orderMatcher;
    }

    public Mono<String> processOrder(OrderDto orderDto) {
        return Mono.fromCallable(() -> {
            // Process the order in a separate thread and return the result
            Order order = EntityDtoMapper.toEntity(orderDto);
            orderMatcher.addOrder(order);
            orderMatcher.matchOrders();
            return "Order processed: " + order;
        }).subscribeOn(Schedulers.boundedElastic()); // Asynchronous non-blocking processing
    }
}