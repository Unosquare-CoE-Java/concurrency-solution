package coe.unosquare.controller;

import coe.unosquare.model.ApiResponse;
import coe.unosquare.model.Order;
import coe.unosquare.model.dto.OrderDto;
import coe.unosquare.service.OrderService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import reactor.core.publisher.Mono;

@RestController
@RequestMapping("/orders")
public class OrderController {

    private final OrderService orderService;

    public OrderController(OrderService orderService) {
        this.orderService = orderService;
    }

    @PostMapping("/submit")
    public Mono<ResponseEntity<ApiResponse>> submitOrder(@RequestBody OrderDto orderDto) {
        return orderService.processOrder(orderDto)
                .map(result -> {
                    ApiResponse apiResponse = new ApiResponse(
                            true, "Order processed successfully", result
                    );
                    return ResponseEntity.status(HttpStatus.ACCEPTED).body(apiResponse); //CREATED
                }).onErrorResume(exception -> {
                    ApiResponse apiResponse = new ApiResponse(
                            false, "Error processing order: " + exception.getMessage(), null
                    );
                    return Mono.just(ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(apiResponse));
                });
    }
}